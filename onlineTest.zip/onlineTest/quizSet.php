
<?php include_once 'header.php'; include_once 'function.php'; ?>
<?php
$number = '';
$course = '';
$subject = '';
if(isset($_POST['submitNum'])) {

  $course = $_POST['modalCourse'];
  $subject = $_POST['modalSubject'];
  $number = $_POST['questionNo'];
}
?>

<?php
if(isset($_POST['subject_submit'])) {
  $count = $_POST['countNum'];
  $asData = array(
    'course_id' => $_POST['courseId'],
    'subject_id'  => $_POST['subjectId'],
    'set_number' => ucwords($_POST['setNumber']),
    'question_type' => ucwords($_POST['quesType']),
    'timming' => ucwords($_POST['timming'])
  );
  for ($i=1; $i <= $count; $i++) { 
    $ques=ucwords($_POST['ques'.$i]);
    $option_a=ucwords($_POST['option_a'.$i]);
    $option_b=ucwords($_POST['option_b'.$i]);
    $option_c=ucwords($_POST['option_c'.$i]);
    $option_d=ucwords($_POST['option_d'.$i]);
    $true_ans = ucwords($_POST['trueAns'.$i]);

    $data = array (
      'course_id' => $_POST['courseId'],
      'subject_id'  => $_POST['subjectId'],
      'set_number' => ucwords($_POST['setNumber']),
      'question'  => $ques,
      'option_one'  => $option_a,
      'option_two'  => $option_b,
      'option_three'  => $option_c,
      'option_four' => $option_d,
      'correct_ans' => $true_ans      
    );    
    $crud->insertRecord('quiz_set_question', $data);
  }
  if($crud->insertRecord('quiz_set', $asData)) {
    echo "<script> alert('Quiz Set Added Successfuly..!'); window.location.href = 'quizSetView.php'; </script>";
  } else {
    echo $this->conn->error;
  }
}
?>

<script>
	function getSub(str)
	{
		if(str.length == 0){
			document.getElementById('showSub').innerHTML = '';
			return;
		} else {
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
				//alert(str);
				if(this.readyState == 4 && this.status == 200) {
					document.getElementById('showSub').innerHTML = this.responseText;
				}
			};
			xmlhttp.open('GET', 'showSubject.php?sub=' +str, true);
			xmlhttp.send();
		}
	}

  function show() {
    var course = document.getElementById('showCourse').value;
    var subject = document.getElementById('showSubject').value;
    document.getElementById('course').value = course;
    document.getElementById('subject').value = subject;
    $("#myModal").modal('show');
  };

  $(document).ready(function() {
    $("#question_option").show();
  });
</script>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
  	<h1> Set Quiz Question </h1>
  	<ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      <li><a href="#"> Manage Quiz Set </a></li>
      <li class="active"> Set Quiz Question </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title"> Add Courses -:- </h3>
          </div>

          <form role="form" method="post">
            <div class="box-body">
              <input type="hidden" name="courseId" class="form-control" value="<?php echo $course; ?>">
              <input type="hidden" name="subjectId" class="form-control" value="<?php echo $subject; ?>">
              <input type="hidden" name="countNum" class="form-control" value="<?php echo $number; ?>">

              <div class="form-group">
                <label class="col-md-2 col-sm-2 col-xs-12 label-control"> Course Name :</label>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <select class="form-control" name="courseCate" onchange="getSub(this.value)" id="showCourse">
                    <option value="" selected disabled="disabled"> Select Course Category </option>
                  <?php
                    $result = $crud->selectRecord('course_cate');
                    foreach($result as $show) {
                  ?>
                    <option value="<?php echo $show['id']; ?>"> <?php echo $show['course_category']; ?> </option>
                  <?php } ?>
                  </select>                 
                </div>

                <label class="col-md-2 col-sm-2 col-xs-12 label-control"> Course Subject :</label>
                <div class="col-md-4 col-sm-4 col-xs-12" id="showSub">
                  <input type="text" name="course_sub" class="form-control" placeholder="Course Subject..!" disabled="disabled">
                </div>
                <div class="clearfix"></div>
              </div>

              <div class="form-group">
                <label class="col-md-2 col-sm-2 col-xs-12 label-control"> Question Type :</label>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <textarea name="quesType" class="form-control" placeholder="Question Type..!" rows="3"></textarea>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12">
                  <label> Timming (In Minutes) :</label>
                  <input type="text" name="timming" class="form-control" placeholder="Timming In Minutes..!">
                </div> 

                <div class="col-md-3 col-sm-3 col-xs-12">
                  <label> Set Number :</label>
                  <input type="text" name="setNumber" class="form-control" placeholder="Set Number..!">
                </div>                
                <div class="clearfix"></div><hr>
              </div>

              <?php
                for ($i=1; $i <= $number; $i++) { 
              ?>
              <div class="form-group" id="question_option">
                <label class="col-md-2 col-sm-2 col-xs-12 label-control"> Question <?php echo $i.' :-'; ?> </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <textarea name="ques<?=$i?>" placeholder="Put Your Question Here..!" class="form-control" rows="3"></textarea>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-12">
                  <label> Correct Ans. : </label>
                  <input type="text" name="trueAns<?=$i?>" class="form-control" placeholder="Input Here Correct Answer..!">
                </div>
                <div class="clearfix"></div><br>

                <label class="col-md-1 col-sm-1 col-xs-12 label-control"> Option A. </label>
                <div class="col-md-2 col-sm-2 col-xs-12">
                  <input type="text" name="option_a<?=$i?>" class="form-control" placeholder="Put Option A..!">
                </div>

                <label class="col-md-1 col-sm-1 col-xs-12 label-control"> Option B. </label>
                <div class="col-md-2 col-sm-2 col-xs-12">
                  <input type="text" name="option_b<?=$i?>" class="form-control" placeholder="Put Option B..!">
                </div>

                <label class="col-md-1 col-sm-1 col-xs-12 label-control"> Option C. </label>
                <div class="col-md-2 col-sm-2 col-xs-12">
                  <input type="text" name="option_c<?=$i?>" class="form-control" placeholder="Put Option C..!">
                </div>

                <label class="col-md-1 col-sm-1 col-xs-12 label-control"> Option D. </label>
                <div class="col-md-2 col-sm-2 col-xs-12">
                  <input type="text" name="option_d<?=$i?>" class="form-control" placeholder="Put Option D..!">
                </div>
                <div class="clearfix"></div><br><hr>
              </div>
              <?php } ?>

              <div class="clearfix"></div><br>
              <div class="form-group">
                <div class="col-md-offset-6 col-sm-offset-6 col-xs-offset-6">
                  <input type="submit" name="subject_submit" value="Submit" class="btn btn-warning">
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"> Inter The Number Of Question -:-</h4>
      </div>
      <div class="modal-body">
        <form role="form" method="post">
          <div class="box-body">

            <input type="hidden" name="modalCourse" id="course">
            <input type="hidden" name="modalSubject" id="subject">

            <div class="form-group">
              <label class="col-md-4 col-sm-4 col-xs-12 label-control"> No Of Question :</label>
              <div class="col-md-8 col-sm-8 col-xs-12">
                <input type="text" name="questionNo" class="form-control" id="quesNum" placeholder="Number Of Question..!">
              </div>
            </div>
            <div class="clearfix"></div>

            <div>
              <input type="submit" name="submitNum" class="btn btn-warning" value="Get Block">  
            </div>

          </div>
        </form>
      </div>
    </div>

  </div>
</div>

<?php include_once 'footer.php'; ?>