
<?php include_once 'header.php'; include_once 'function.php'; ?>

<style>
  .table thead th {
    text-align: center;
  }
  .table tbody td {
    text-align: center;
  }
  ol li {
    font-size: 1.3em;
  }
</style>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> View Quiz Set </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      <li class="active"> View Quiz Set </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title"> View Quiz Set -:- </h3>
          </div>

          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th> # </th>
                  <th> Course Name </th>
                  <th> Subject Name </th>
                  <th> Set Number </th>
                  <th> Question Type </th>
                  <th> Timming </th>
                  <th> Action </th>
                </tr>
              </thead>

              <tbody>
              <?php
                $num = 1;
                $show = $crud->selectToJoin('quiz_set', 'course_id', 'subject_id', 'course_cate', 'id', 'course_subject', 'id');
                //print_r($show);
                //exit();
                foreach ($show as $showRecord) {
              ?>
                <tr>
                  <td> <?php echo $num; ?> </td>
                  <td> <?php echo $showRecord['course_category']; ?> </td>
                  <td> <?php echo $showRecord['course_subject']; ?> </td>
                  <td> <?php echo $showRecord['set_number']; ?> </td>
                  <td> <?php echo $showRecord['question_type']; ?> </td>
                  <td> <?php echo $showRecord['timming']; ?> </td>

                  <td>
                    <a href="#" data-toggle="modal" data-target="#myModal<?php echo $num; ?>"><img src="dist/img/start.png"></a>
                  </td>
                </tr>
              <?php $num++; } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php 
  $count = 1;
  $showModal =$crud->selectToJoin('quiz_set', 'course_id', 'subject_id', 'course_cate', 'id', 'course_subject', 'id');
  foreach($showModal as $show) {
?>
  <div id="myModal<?php echo $count; ?>" class="modal fade" role="dialog">
    <div class="modal-dialog" style="width: 800px">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"> Info Before Start Test </h4>
      </div>
      <div class="modal-body">
        <center><h4>&nbsp;&nbsp; Before Start Your Quiz Test, Read Instruction Carefully..!</h4></center>
        <ol start="1">
          <b><li> You will be given <?php echo $show['timming'];?> Minutes to complete the examination. You should
          allocate your time approximately as follows.</li></b>
          <b><li> Please read all questions carefully and make sure you understand the facts before you begin
          answering. Write legibly and be as concise as possible. </li></b>
          <b><li> Good luck and have a nice vacation. </li></b>
        </ol>
        <center><a href="startTest.php?course=<?php echo $show['course_id'];?>&subject=<?php echo $show['subject_id'];?>&set=<?php echo $show['set_number'];?>" class="btn btn-warning"> Start Test </a></center>
      </div>
    </div>

    </div>
  </div>
<?php 
  $count++; }

include_once 'footer.php'; ?>