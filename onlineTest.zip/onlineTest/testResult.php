
<?php 
	include_once 'header.php';
	include_once 'function.php';

	$course = $_GET['course'];
	$subject = $_GET['subject'];
	$set = $_GET['set'];

	$showResult = $crud->selectByDataUser('test_record', 'course_id', $course, 'subject_id', $subject, 'set_num', $set, 'user_id', $_SESSION['id']);

	$number = $crud->numOfRowsUser('test_record', 'course_id', $course, 'subject_id', $subject, 'set_num', $set, 'user_id', $_SESSION['id']);
	
	$checkWrong = $crud->selectByWhere('test_record', 'course_id', $course, 'subject_id', $subject, 'set_num', $set, 'status', 'Wrong', 'user_id', $_SESSION['id']);

	$checkCorrect = $crud->selectByWhere('test_record', 'course_id', $course, 'subject_id', $subject, 'set_num', $set, 'status', 'Correct', 'user_id', $_SESSION['id']);

	$accuracy = ($checkCorrect * 100)/$number;
?>

<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1> Test Result </h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      		<li><a href="#"> View Quiz Set </a></li>
      		<li class="active"> Quiz Result </li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="box box-primary">
					<div class="box-header">
						<h3 class="box-title"> Test Result -:- </h3>
					</div>

					<div class="box-body">
						<div class="col-md-offset-3 col-md-3 col-xs-6">
							<h4 class="box-title"> Total Number Of Question </h4>
							<h4 class="box-title"> Total Question Attemped </h4>
							<h4 class="box-title"> Total Correct Answer </h4>
							<h4 class="box-title"> Total Wrong Answer </h4>
							<h4 class="box-title"> Accuracy </h4>
						</div>

						<div class="col-md-3 col-xs-6">
							<h4 class="box-title"> <?php if(!empty($number)) {echo ':&nbsp;&nbsp;'.$number.' Questions.';} else { echo ':&nbsp;&nbsp; 0 Questions.';} ?> </h4>

							<h4 class="box-title"> <?php if(!empty($number)) {echo ':&nbsp;&nbsp;'.$number.' Questions.';} else { echo ':&nbsp;&nbsp; 0 Questions.';} ?> </h4>

							<h4 class="box-title"> <?php if(!empty($checkCorrect)) {echo ':&nbsp;&nbsp;'.$checkCorrect.' Questions.';} else { echo ':&nbsp;&nbsp; 0 Questions.';} ?> </h4>

							<h4 class="box-title"> <?php if(!empty($checkWrong)) {echo ':&nbsp;&nbsp;'.$checkWrong.' Questions.';} else { echo ':&nbsp;&nbsp; 0 Questions.';} ?> </h4>

							<h4 class="box-title"> <?php if(!empty($accuracy)) {echo ':&nbsp;&nbsp;'.number_format((float)$accuracy,'2','.','').' %';} else { echo ':&nbsp;&nbsp; 0.00 %';} ?> </h4>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>

<?php include_once 'footer.php'; ?>
