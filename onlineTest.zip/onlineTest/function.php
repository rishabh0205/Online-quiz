
<?php
	include_once 'database/connection.php';
	date_default_timezone_set('Asia/Kolkata');

	class DataOperation extends Connection {

	// Insert Record into Database
		public function insertRecord($tableName, $data)
		{
			$sql = "INSERT INTO ".$tableName;
			$sql .= "(".implode(", ", array_keys($data)).") VALUES ";
			$sql .= "('".implode("', '", array_values($data)). "')";

			$query = $this->conn->query($sql);
			if($query) {
				return true;
			}
		}


	// Delete Record From Database
		public function deleteRecord($table, $where) {

			$sql = '';
			$condition = '';
			foreach ($where as $key => $value) 
			{
				$condition .= $key .'="'.$value.'" AND ';
			}
			$condition = substr($condition, 0, -5);
			$sql = "DELETE FROM ".$table." WHERE ".$condition;
			if($this->conn->query($sql))
			{
				return true;
			}
		}



		public function updateReportData($tableName, $dataOne, $dataOneValue, $dataTwo, $dataTwoValue, $dataThree, $dataThreeValue, $dataFour, $dataFourValue, $dataFive, $dataFiveValue, $dataSix, $dataSixValue, $dataSeven, $dataSevenValue)
		{
			$abc = "UPDATE ".$tableName." SET ".$dataFive." = '".$dataFiveValue;
			$abc .= "', ".$dataSix." = '".$dataSixValue."', ".$dataSeven." = '".$dataSevenValue;
			$abc .= "' WHERE ".$dataOne." = '".$dataOneValue;
			$abc .= "' AND ".$dataTwo." = '".$dataTwoValue."' AND ".$dataThree." = '".$dataThreeValue;
			$abc .="' AND ".$dataFour." = '".$dataFourValue."'";
			echo $abc;
			$rs_edit = $this->conn->query($abc);
			if($rs_edit) {
				return true;
			}
		}


	// Select Record From Database
		public function selectRecord($tableName)
		{
			$sql = "SELECT * FROM ".$tableName;
			$sql .= " ORDER BY id DESC";
			//echo $sql;
			$array = array();
			$getData = $this->conn->query($sql);
			while($getDataShow = $getData->fetch_assoc()) {
				$array[] = $getDataShow;
			}
			return $array;
		}

		public function selectReportData($tableName, $dataOne, $dataOneValue, $dataTwo, $dataTwoValue, $dataThree, $dataThreeValue, $dataFour, $dataFourValue)
		{
			$abc = "SELECT * FROM ".$tableName." WHERE ".$dataOne." = '".$dataOneValue;
			$abc .= "' AND ".$dataTwo." = '".$dataTwoValue."' AND ".$dataThree." = '".$dataThreeValue;
			$abc .="' AND ".$dataFour." = '".$dataFourValue."'";
			echo $abc;
			$rs_data = $this->conn->query($abc);
			$res_data = $rs_data->fetch_assoc();
			return $res_data;
		}

		public function selectByAjax($tableName, $where, $value)
		{
			$sql = "SELECT * FROM ".$tableName;
			$sql .= " WHERE ".$where." = '".$value;
			$sql .= "' ORDER BY id DESC";
			//echo $sql;
			$array = array();
			$ajaxData = $this->conn->query($sql);
			while($ajaxDataShow = $ajaxData->fetch_assoc()) {
				$array[] = $ajaxDataShow;
			}
			return $array;
		}

		public function selectToJoin($tableNameOne, $clmNameOne, $clmNameOne_One, $tableNameTwo, $clmNameTwo, $tableNameThree, $clmNameThree)
		{
			$sql = "SELECT * FROM ".$tableNameOne." INNER JOIN ";
			$sql .= $tableNameTwo." ON ".$tableNameOne.".".$clmNameOne." = ".$tableNameTwo.".".$clmNameTwo;
			$sql .= " INNER JOIN ".$tableNameThree." ON ".$tableNameOne.".".$clmNameOne_One." = ".$tableNameThree;
			$sql .= ".".$clmNameThree;
			//echo $sql;
			$array = array();
			$joinData = $this->conn->query($sql);
			while($dataJoin = $joinData->fetch_assoc()) {
				$array[] = $dataJoin;
			}
			return $array;
		}

		public function selectSessionJoin($tableNameOne, $clmNameOne, $clmNameOne_One, $tableNameTwo, $clmNameTwo, $tableNameThree, $clmNameThree, $tableNameFour, $clmNameFour)
		{
			$sql = "SELECT * FROM ".$tableNameOne." INNER JOIN ";
			$sql .= $tableNameTwo." ON ".$tableNameOne.".".$clmNameOne." = ".$tableNameTwo.".".$clmNameTwo;
			$sql .= " INNER JOIN ".$tableNameThree." ON ".$tableNameOne.".".$clmNameOne_One." = ".$tableNameThree.".".$clmNameThree." WHERE ".$tableNameFour." = '".$clmNameFour."'";
			//echo $sql;
			$array = array();
			$rsJoin = $this->conn->query($sql);
			while($rssJoin = $rsJoin->fetch_assoc()) {
				$array[] = $rssJoin;
			}
			return $array;
		}

		public function selectAdminJoin($tableNameOne, $clmNameOne, $clmNameOne_One, $clmNameOne_Two, $tableNameTwo, $clmNameTwo, $tableNameThree, $clmNameThree, $tableNameFour, $clmNameFour)
		{
			$sql = "SELECT * FROM ".$tableNameOne." INNER JOIN ";
			$sql .= $tableNameTwo." ON ".$tableNameOne.".".$clmNameOne." = ".$tableNameTwo.".".$clmNameTwo;
			$sql .= " INNER JOIN ".$tableNameThree." ON ".$tableNameOne.".".$clmNameOne_One." = ".$tableNameThree.".".$clmNameThree;
			$sql .=" INNER JOIN ".$tableNameFour." ON ".$tableNameOne.".".$clmNameOne_Two." = ".$tableNameFour.".".$clmNameFour." ORDER BY ".$tableNameOne.".id DESC";
			//echo $sql;
			$array = array();
			$rrJoin = $this->conn->query($sql);
			while($rasJoin = $rrJoin->fetch_assoc()) {
				$array[] = $rasJoin;
			}
			return $array;
		}

		public function selectById($tableNameOne, $clmName, $value)
		{
			$getData = "SELECT * FROM ".$tableNameOne." WHERE ";
			$getData .= $clmName." = '".$value."'";
			//echo $getData;
			$rs_getData = $this->conn->query($getData);
			$res_getData = $rs_getData->fetch_assoc();
			return $res_getData;
		}

		public function selectBy($tableNameOne, $clmName, $value)
		{
			$getData = "SELECT * FROM ".$tableNameOne." WHERE ";
			$getData .= $clmName." = '".$value."'";
			//echo $getData;
			$re_getData = $this->conn->query($getData);
			$rss_getData = $re_getData->fetch_assoc();
			return $rss_getData;
		}

		public function selectByWhere($tableNameOne, $clmNameOne, $clmOneData, $clmNameTwo, $clmTwoData, $clmNameThree, $clmThreeData, $clmNameFour, $clmFourData, $clmNameFive, $clmFiveData)
		{
			$sql = "SELECT * FROM ".$tableNameOne." WHERE ";
			$sql .= $clmNameOne." = '".$clmOneData."' AND ".$clmNameTwo." = '".$clmTwoData;
			$sql .= "' AND ".$clmNameThree." = '".$clmThreeData."' AND ".$clmNameFour." = '".$clmFourData."' AND ".$clmNameFive." = '".$clmFiveData."'";
			//echo $sql;
			$ra = $this->conn->query($sql);
			$array = $ra->num_rows;
			return $array;
		}

		public function selectByData($tableNameOne, $clmNameOne, $clmOneData, $clmNameTwo, $clmTwoData, $clmNameThree, $clmThreeData)
		{
			$sql = "SELECT * FROM ".$tableNameOne." WHERE ";
			$sql .= $clmNameOne." = '".$clmOneData."' AND ".$clmNameTwo." = '".$clmTwoData;
			$sql .= "' AND ".$clmNameThree." = '".$clmThreeData."'";
			//echo $sql;
			$array = array();
			$dataById = $this->conn->query($sql);
			while($idData = $dataById->fetch_assoc()) {
				$array[] = $idData;
			}
			return $array;
		}

		public function selectByDataUser($tableNameOne, $clmNameOne, $clmOneData, $clmNameTwo, $clmTwoData, $clmNameThree, $clmThreeData, $clmNameFour, $clmFourData)
		{
			$sql = "SELECT * FROM ".$tableNameOne." WHERE ";
			$sql .= $clmNameOne." = '".$clmOneData."' AND ".$clmNameTwo." = '".$clmTwoData;
			$sql .= "' AND ".$clmNameThree." = '".$clmThreeData."' AND ".$clmNameFour." = '".$clmFourData."'";
			//echo $sql;
			$array = array();
			$dataById = $this->conn->query($sql);
			while($idData = $dataById->fetch_assoc()) {
				$array[] = $idData;
			}
			return $array;
		}

		public function selectBySingleValue($tableNameOne, $clmNameOne, $clmOneData, $clmNameTwo, $clmTwoData, $clmNameThree, $clmThreeData)
		{
			$sql = "SELECT * FROM ".$tableNameOne." WHERE ";
			$sql .= $clmNameOne." = '".$clmOneData."' AND ".$clmNameTwo." = '".$clmTwoData;
			$sql .= "' AND ".$clmNameThree." = '".$clmThreeData."'";
			//echo $sql;
			$ra_data = $this->conn->query($sql);
			$rdj_data = $ra_data->fetch_assoc();
			return $rdj_data;
		}

		public function checkLogin($table, $colName_one, $data_one, $colName_two, $data_two) 
		{
			$sql = "SELECT * FROM ".$table." WHERE ";
			$sql .= $colName_one." = '".$data_one."' AND ";
			$sql .= $colName_two." = '".$data_two."'";			
			$ra_check = $this->conn->query($sql);
			if($ra_check->num_rows > 0) {
				$ras_check = $ra_check->fetch_assoc();
				return $ras_check;
			} else {
				return 0;
			}
		}

		public function numOfRows($tableNameOne, $clmNameOne, $clmOneData, $clmNameTwo, $clmTwoData, $clmNameThree, $clmThreeData)
		{
			$sql = "SELECT * FROM ".$tableNameOne." WHERE ";
			$sql .= $clmNameOne." = '".$clmOneData."' AND ".$clmNameTwo." = '".$clmTwoData;
			$sql .= "' AND ".$clmNameThree." = '".$clmThreeData."'";

			$rg_row = $this->conn->query($sql);
			$number = $rg_row->num_rows;
			return $number;
		}

		public function numOfRowsUser($tableNameOne, $clmNameOne, $clmOneData, $clmNameTwo, $clmTwoData, $clmNameThree, $clmThreeData, $clmNameFour, $clmFourData)
		{
			$sql = "SELECT * FROM ".$tableNameOne." WHERE ";
			$sql .= $clmNameOne." = '".$clmOneData."' AND ".$clmNameTwo." = '".$clmTwoData;
			$sql .= "' AND ".$clmNameThree." = '".$clmThreeData."' AND ".$clmNameFour." = '".$clmFourData."'";

			$rg_row = $this->conn->query($sql);
			$number = $rg_row->num_rows;
			return $number;
		}
	}

	$crud = new DataOperation;
?>