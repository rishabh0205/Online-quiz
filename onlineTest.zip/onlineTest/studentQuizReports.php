
<?php include_once 'header.php'; include_once 'function.php'; ?>

<style>
  .table thead th {
    text-align: center;
  }
  .table tbody td {
    text-align: center;
  }
</style>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> View Report </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      <li><a href="#"> Manage Student View </a></li>
      <li class="active"> Student Report </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title"> View User Report -:- </h3>
          </div>

          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th> # </th>
                  <th> User Name </th>
                  <th> Course Name </th>
                  <th> Subject Name </th>
                  <th> Set Number </th>
                  <th> No of Question </th>
                  <th> Correct Answer </th>
                  <th> Wrong Answer </th>
                  <th> Accuracy </th>
                </tr>
              </thead>

              <tbody>
              <?php
                $num = 1;
                $show = $crud->selectAdminJoin('test_report', 'course_id', 'subject_id', 'user_id', 'course_cate', 'id', 'course_subject', 'id', 'login_auth', 'id');
                //print_r($show);
                //exit();
                foreach ($show as $showRecord) {
              ?>
                <tr>
                  <td> <?php echo $num; ?> </td>
                  <td> <?php echo $showRecord['name']; ?> </td>
                  <td> <?php echo $showRecord['course_category']; ?> </td>
                  <td> <?php echo $showRecord['course_subject']; ?> </td>
                  <td> <?php echo $showRecord['set_num']; ?> </td>
                  <td> <?php echo $showRecord['no_of_question'].' Question'; ?> </td>
                  <td> <?php echo $showRecord['correct_answer'].' Answer'; ?> </td>
                  <td> <?php echo $showRecord['wrong_answer'].' Answer'; ?> </td>
                  <td> <?php echo $showRecord['accuracy']; ?> </td>
                </tr>
              <?php $num++; } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once 'footer.php'; ?>