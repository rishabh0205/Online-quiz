
<?php include_once 'header.php'; include_once 'function.php'; ?>

<style>
  .table thead th {
    text-align: center;
  }
  .table tbody td {
    text-align: center;
  }
</style>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> View Report </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      <li><a href="#"> Manage Student View </a></li>
      <li class="active"> Student Report </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title"> View User Report -:- </h3>
          </div>

          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th> # </th>
                  <th> User Name </th>
                  <th> Email Id </th>
                  <th> Address </th>
                  <th> Contact </th>
                  <th> Type </th>
                </tr>
              </thead>

              <tbody>
              <?php
                $num = 1;
                $show = $crud->selectByAjax('login_auth', 'type', 'User');
                //print_r($show);
                //exit();
                foreach ($show as $showRecord) {
              ?>
                <tr>
                  <td> <?php echo $num; ?> </td>
                  <td> <?php echo $showRecord['name']; ?> </td>
                  <td> <?php echo $showRecord['email']; ?> </td>
                  <td> <?php echo $showRecord['address']; ?> </td>
                  <td> <?php echo $showRecord['phone']; ?> </td>
                  <td> <?php echo $showRecord['type']; ?> </td>
                </tr>
              <?php $num++; } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once 'footer.php'; ?>