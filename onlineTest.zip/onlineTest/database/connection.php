<?php 
	
	session_start();

	class Connection {

		protected $host = 'localhost';
		protected $user = 'root';
		protected $pass = '';
		protected $database = 'online_test';

		public $conn;

		public function __construct() {

			$this->conn = new mysqli ($this->host, $this->user, $this->pass, $this->database);

			/*if ($this->conn) {

				echo 'Connected';
			} else {

				echo $this->conn->error;
			}*/
		}
	}

	$connect = new Connection;

?>