
<?php include_once 'header.php'; include_once 'function.php'; ?>

<?php
  if(isset($_POST['subject_submit'])) {
    $subject = array(
      'course_cate_id' => $_POST['courseCate'],
      'course_subject' => ucwords($_POST['course_sub'])
    );
    if($crud->insertRecord('course_subject', $subject)){
      echo "<script> alert('Subject Added Successfully..!'); window.location.href = 'courseSub.php'; </script>";
    } else {
      echo $this->conn->error;
    }
  }


  if(isset($_GET['del'])) {
    $where = array('id' => $_GET['del']);
    if($crud->deleteRecord('course_subject', $where)) {
      echo "<script> alert('Course Subject Deleted Successfully..!'); window.location.href = 'courseSub.php'; </script>";
    } else {
      echo $this->conn->error;
    }
  }
?>
<style>
  .table thead th {
    text-align: center;
  }
  .table tbody td {
    text-align: center;
  }
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <section class="content-header">
    	<h1> Course Subject </h1>
    	<ol class="breadcrumb">
      	<li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      	<li><a href="#"> Courses </a></li>
      	<li class="active"> Course Subject </li>
    	</ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">

        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title"> Add Subject -:- </h3>
          </div>
          <form role="form" method="post">
            <div class="box-body">

              <div class="form-group">
                <label class="col-md-2 col-sm-2 col-xs-12 label-control"> Course Name :</label>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <select class="form-control" name="courseCate">
                    <option value="" selected disabled="disabled"> Select Course Category </option>
                  <?php
                    $result = $crud->selectRecord('course_cate');
                    foreach($result as $show) {
                  ?>
                    <option value="<?php echo $show['id']; ?>"> <?php echo $show['course_category']; ?> </option>
                  <?php } ?>
                  </select>
                </div>

                <label class="col-md-2 col-sm-2 col-xs-12 label-control"> Course Subject :</label>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <input type="text" name="course_sub" class="form-control" placeholder="Course Subject..!">
                </div>
                <div class="clearfix"></div>
              </div>

              <div class="form-group">
                <div class="col-md-offset-5 col-sm-offset-5 col-xs-offset-5">
                  <input type="submit" name="subject_submit" value="Submit" class="btn btn-warning">
                </div>
              </div>
            </div>

          </form>
        </div>

        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title"> View Course Subject -:- </h3>
          </div>

          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th> # </th>
                  <th> Course Name </th>
                  <th> Subject Name </th>
                  <th> Action </th>
                </tr>
              </thead>
              <tbody>
              <?php
                $num = 1;
                $show = $crud->selectRecord('course_subject');
                foreach($show as $showRecord) {
              ?>
                <tr>
                  <td> <?php echo $num; ?> </td>
                  <td> <?php echo $showRecord['course_cate_id']; ?> </td>
                  <td> <?php echo $showRecord['course_subject']; ?> </td>
                  <td>
                    <a href="courseSub.php?del=<?php echo $showRecord['id']; ?>" onclick="return confirm('Are You Sure..?')"><img src="dist/img/trash.png"></a>
                    &nbsp;&nbsp;&nbsp;
                    <a href="#?edit=<?php echo $showRecord['id']; ?>"><img src="dist/img/edit.png"></a>
                  </td>
                </tr>
              <?php $num++; } ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  </section>
</div>

<?php include_once 'footer.php'; ?>