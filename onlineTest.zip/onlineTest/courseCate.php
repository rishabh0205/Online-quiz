
<?php include_once 'header.php'; include_once 'function.php'; ?>

<?php
  if(isset($_POST['course_submit'])) {
    $course = array(
      'course_category' => ucwords($_POST['courseCate'])
    );
    if($crud->insertRecord('course_cate', $course)){
      echo "<script> alert('Course Added Successfully..!'); window.location.href = 'courseCate.php' </script>";
    } else {
      echo $this->conn->error;
    }
  }


  if(isset($_GET['del'])) {
    $where = array('id' => $_GET['del']);
    if($crud->deleteRecord('course_cate', $where)) {
      echo "<script> alert('Course Category Deleted Successfully..!'); window.location.href = 'courseCate.php'; </script>";
    } else {
      echo $this->conn->error;
    }
  }
?>
<style>
  .table thead th {
    text-align: center;
  }
  .table tbody td {
    text-align: center;
  }
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <section class="content-header">
    	<h1> Course Category </h1>
    	<ol class="breadcrumb">
      	<li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      	<li><a href="#"> Courses </a></li>
      	<li class="active"> Course Category </li>
    	</ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title"> Add Courses -:- </h3>
          </div>
          <form role="form" method="post">
            <div class="box-body">

              <div class="form-group">
                <label class="col-md-2 col-sm-2 col-xs-12 label-control"> Course Name :</label>
                <div class="col-md-4 col-sm-4 col-xs-12">
                  <input type="text" name="courseCate" class="form-control" placeholder="Course Name..!" required="required">
                </div>

                <!-- <div class="col-md-offset-11 col-sm-offset-11 col-xs-offset-10"> -->
                  <input type="submit" name="course_submit" value="Submit" class="btn btn-warning">
                <!-- </div> -->
              </div>
            </div>

          </form>
        </div>

        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title"> View Course Category -:- </h3>
          </div>

          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th> # </th>
                  <th> Course Name </th>
                  <th> Action </th>
                </tr>
              </thead>
              <tbody>
              <?php
                $num = 1;
                $show = $crud->selectRecord('course_cate');
                foreach($show as $showRecord) {
              ?>
                <tr>
                  <td> <?php echo $num; ?> </td>
                  <td> <?php echo $showRecord['course_category']; ?> </td>
                  <td>
                    <a href="courseCate.php?del=<?php echo $showRecord['id']; ?>" onclick="return confirm('Are You Sure..?')"><img src="dist/img/trash.png"></a>
                    &nbsp;&nbsp;&nbsp;
                    <a href="#?edit=<?php echo $showRecord['id']; ?>"><img src="dist/img/edit.png"></a>
                  </td>
                </tr>
              <?php $num++; } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once 'footer.php'; ?>