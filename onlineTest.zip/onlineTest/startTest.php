
<?php 
include_once 'header.php';
include_once 'function.php';
date_default_timezone_set('Asia/Kolkata');

$course = $_GET['course'];
$subject = $_GET['subject'];
$set = $_GET['set'];

$show_cate = $crud->selectById('course_cate', 'id', $course);
$show_sub = $crud->selectBy('course_subject', 'id', $subject);
$number = $crud->numOfRows('quiz_set_question', 'course_id', $course, 'subject_id', $subject, 'set_number', $set);

if(isset($_POST['submitExam'])) {

	$report = array(
		'user_id' => $_SESSION['id'],
		'course_id' => $course,
		'subject_id' => $subject,
		'set_num' => $set,
		'no_of_question' => $number,
		'test_date' => date('Y-m-d')
	);

	for($i=1; $i<=$number; $i++) {		
		if($_POST['optionCheck'.$i] == $_POST['correct'.$i]) {
			$status = 'Correct';
		} else if($_POST['optionCheck'.$i] != $_POST['correct'.$i]) {
			$status = 'Wrong';
		} else if(empty($_POST['optionCheck'.$i])) {
			$status = 'Empty';
		}
		$ques = array(
			'user_id' => $_SESSION['id'],
			'course_id' => $course,
			'subject_id' => $subject,
			'set_num' => $set,
			'question' => $_POST['question'.$i],
			'option_check' => $_POST['optionCheck'.$i],
			'correct_ans' => $_POST['correct'.$i],
			'status' => $status
		);
		$crud->insertRecord('test_record', $ques);
	}

	if($crud->insertRecord('test_report', $report)) {
		
		$dataGet = $crud->selectReportData('test_record', 'user_id', $_SESSION['id'], 'course_id', $course, 'subject_id', $subject, 'set_num', $set);
		$checkWrong = $crud->selectByWhere('test_record', 'course_id', $course, 'subject_id', $subject, 'set_num', $set, 'status', 'Wrong', 'user_id', $_SESSION['id']);
		$checkCorrect = $crud->selectByWhere('test_record', 'course_id', $course, 'subject_id', $subject, 'set_num', $set, 'status', 'Correct', 'user_id', $_SESSION['id']);
		$accuracy = ($checkCorrect * 100)/$number;
		$data = $crud->updateReportData('test_report', 'user_id', $_SESSION['id'], 'course_id', $course, 'subject_id', $subject, 'set_num', $set, 'correct_answer', $checkCorrect, 'wrong_answer', $checkWrong, 'accuracy', number_format((float)$accuracy,'2','.','').' %');

		echo "<script> alert('Your Test Submitted Successfully..! Please Wait Here To Get Your Result..!'); window.location.href = 'testResult.php?course=$course&subject=$subject&set=$set'; </script>";
	} else {
		echo $this->conn->error;
	}
}
?>

<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1> Start Your Exam Here </h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
			<li class="active"> View Quiz Set </li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="box box-primary">
					<div class="box-header">
						<h3 class="box-title"> Set : <?php echo $set; ?> &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; Course : <?php echo $show_cate['course_category'];?> &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; Subject : <?php echo $show_sub['course_subject']; ?> &nbsp;&nbsp;&nbsp; | </h3>

						<span id="startBtn" style="float:right">
							<h3 class="box-title"><b> Click Here To Start Exam &nbsp;&nbsp;&nbsp;</b></h3>
							<button type="button" class="btn btn-warning" name="start" onclick="start()"><i class="fa fa-hourglass-start"></i>&nbsp;&nbsp;Start</button>
						</span>
					</div>

					<div class="box-body">
						<div class="col-md-8 col-xs-12">
							<form method="post" >
								<?php
								$num = 1;
								$result = $crud->selectByData('quiz_set_question', 'course_id', $course, 'subject_id', $subject, 'set_number', $set);
							//echo $number;
							//exit();
								foreach($result as $ques) {
									?>
									<div id="showQues<?php echo $num; ?>">
										<h4> <?php echo $num; ?>. &nbsp;&nbsp;&nbsp;&nbsp; <b><?php echo $ques['question']; ?></b></h4>
										<input type="hidden" name="question<?php echo $num; ?>" value="<?php echo $ques['question']; ?>">
										<input type="hidden" name="correct<?php echo $num; ?>" value="<?php echo $ques['correct_ans']; ?>">

										<div class="col-xs-3 col-md-3">
											<p>A. &nbsp;&nbsp;&nbsp;<input type="radio" name="optionCheck<?php echo $num; ?>" value="<?php echo $ques['option_one']; ?>">&nbsp; <?php echo $ques['option_one']; ?> </p>
										</div>
										<div class="col-xs-3 col-md-3">
											<p>B. &nbsp;&nbsp;&nbsp;<input type="radio" name="optionCheck<?php echo $num; ?>" value="<?php echo $ques['option_two']; ?>">&nbsp; <?php echo $ques['option_two']; ?> </p>
										</div>
										<div class="col-xs-3 col-md-3">
											<p>C. &nbsp;&nbsp;&nbsp;<input type="radio" name="optionCheck<?php echo $num; ?>" value="<?php echo $ques['option_three']; ?>">&nbsp; <?php echo $ques['option_three']; ?> </p>
										</div>
										<div class="col-xs-3 col-md-3">
											<p>D. &nbsp;&nbsp;&nbsp;<input type="radio" name="optionCheck<?php echo $num; ?>" value="<?php echo $ques['option_four']; ?>">&nbsp; <?php echo $ques['option_four'].'.'; ?> </p>
										</div><br><br>

										<div class="col-md-6" style="text-align:left">
											<button type="button" class="btn btn-info" <?php if($num==1) echo "disabled"; ?> onclick="showHide(<?=$num-1?>);">Previous</button>

											<button type="button" class="btn btn-info"  <?php if($num==$number) echo "disabled"; ?> onclick="showHide(<?=$num+1?>);">Next</button>
										</div><br><br>

										<div class="form-group">
											<div class="col-md-offset-10 col-xs-offset-10">
												<?php if($num==$number) { ?>
													<input type="submit" name="submitExam" id='form1' value="Submit" class="btn btn-warning">
												<?php } ?>
											</div>
										</div>
									</div>
									<?php $num++; } ?>
								</form>
							</div>


							<div class="col-md-4 col-xs-12" style="border:2px solid #000;border-radius:5px;">
								<?php 
								$result = $crud->selectBySingleValue('quiz_set', 'course_id', $course, 'subject_id', $subject, 'set_number', $set);

								$time = (int)$result['timming'];
								$timer = ($time * 1);
								?>
								<center><h4> Timming : </h4> <h4><b> <span id="time"></span> </b></h4></center>
								<center style="padding-bottom:15px;">
									<h4> Number Of Question : </h4>
									<?php
									for($i=1; $i<=$number; $i++) {
										?>
										<span class="btn btn-success" id="showQues<?=$i?>" onclick="showHide(<?php echo $i; ?>)"> <?php echo $i; ?></span>
									<?php } ?>
								</center>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>

	<script>
		$(document).ready(function (str) {

			$("div[id^='showQues']").hide();
		// $("#showQues1").show();
	});
		function showHide(str){
			$("div[id^='showQues']").hide();
			$("#showQues"+str).show();
		}
		function start(){
			document.getElementById('startBtn').style.display = "none";
			showHide(1);
			startTimer();
		}
		
   	var timer = <?php echo $timer ?>;    // 1 minute timer.... 
   	var min = 0;
   	var sec = 0;

   	function startTimer() {
   		min = parseInt(timer/60);
   		sec = parseInt(timer%60);
   		if(timer<1) {
   			document.getElementById('form1').click();
   		}
   		document.getElementById("time").innerHTML = "<b>Time Left:  </b> " + min.toString() + " : " + sec.toString();
   		timer--;
   		setTimeout(function() {
   			startTimer();
   		}, 1000);
   	}
   	/*function stop() {
   		alert("Thank you for completing the test. You finished the test at: " +  min.toString() + ":" + sec.toString());
   		var result = document.getElementById('time').innerHTML;
   		document.getElementById('input').value = result;
    //window.location.href = "update.php";
}*/
</script>


<?php include_once 'footer.php'; ?>
