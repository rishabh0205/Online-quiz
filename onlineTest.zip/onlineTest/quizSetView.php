
<?php include_once 'header.php'; include_once 'function.php'; ?>

<style>
  .table thead th {
    text-align: center;
  }
  .table tbody td {
    text-align: center;
  }
</style>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> View Quiz Question </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      <li><a href="#"> Manage Quiz Set </a></li>
      <li class="active"> View Quiz Question </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title"> View Quiz Question -:- </h3>
          </div>

          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th> # </th>
                  <th> Course Name </th>
                  <th> Subject Name </th>
                  <th> Set Number </th>
                  <th> Question Type </th>
                  <th> Timming </th>
                  <th> View Set </th>
                  <th> Action </th>
                </tr>
              </thead>

              <tbody>
              <?php
                $num = 1;
                $show = $crud->selectToJoin('quiz_set', 'course_id', 'subject_id', 'course_cate', 'id', 'course_subject', 'id');
                //print_r($show);
                //exit();
                foreach ($show as $showRecord) {
              ?>
                <tr>
                  <td> <?php echo $num; ?> </td>
                  <td> <?php echo $showRecord['course_category']; ?> </td>
                  <td> <?php echo $showRecord['course_subject']; ?> </td>
                  <td> <?php echo $showRecord['set_number']; ?> </td>
                  <td> <?php echo $showRecord['question_type']; ?> </td>
                  <td> <?php echo $showRecord['timming']; ?> </td>

                  <td>
                    <a href="viewQuestion.php?view=<?php echo $showRecord['set_number'];?>&course=<?php echo $showRecord['course_id'];?>&subject=<?php echo $showRecord['subject_id'];?>" target="_blank">
                      <img src="dist/img/view.png">
                    </a>
                  </td>

                  <td>
                    <a href="courseSub.php?del=<?php echo $showRecord['id']; ?>" onclick="return confirm('Are You Sure..?')"><img src="dist/img/trash.png"></a>
                     &nbsp;&nbsp;&nbsp;
                    <a href="#?edit=<?php echo $showRecord['id']; ?>"><img src="dist/img/edit.png"></a>
                  </td>
                </tr>
              <?php $num++; } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once 'footer.php'; ?>