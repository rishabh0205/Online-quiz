<?php
  include_once 'database/connection.php';
  include_once 'function.php';

  if(isset($_POST['login'])) {

    $userName = $_POST['userName'];
    $password = md5($_POST['password']);

    $result = $crud->checkLogin('login_auth', 'email', $userName, 'password', $password);
    if($result == 0){

      echo "<script> alert('Invalid UserName orr Password..!'); window.location.href = 'login.php'; </script>";
    } else {

      $_SESSION['id'] = $result['id'];
      $_SESSION['name'] = $result['name'];
      $_SESSION['email'] = $result['email'];
      $_SESSION['address'] = $result['address'];
      $_SESSION['phone'] = $result['phone'];
      $_SESSION['type'] = $result['type'];
      $_SESSION['image'] = $result['image'];

      echo "<script> alert('Welcome To $_SESSION[name]..!'); window.location.href = 'index.php'; </script>";
    }
  }
?>

<html lang="en" > 
  <head>
    <meta charset="UTF-8">
    <title> Login | Online Test Panel </title>
    <link href="https://fonts.googleapis.com/css?family=Alegreya+Sans+SC&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="style.css"> -->

    <style>
      * {
        letter-spacing: 3px;
        font-family: Cambria;
      }
      body {
        color: white;
        background: -webkit-linear-gradient(left, #3931af, #00c6ff);
      }

      h4 a {
        color: #fff !important;
        text-decoration: none !important;
      }
      h4 a:hover {
        color: #ddd !important;
        text-decoration: none !important;
      }
       
      h1 {
        font-size: 2.5em;
        margin: 0px;
        padding: 0px;
        text-align: center;
      }
       
      div.main {
        width: 410px;
        position: absolute;
        top: 40%;
        left: 50%;
        transform: translate(-50%, -50%);
        vertical-align: middle;
      }
       
      div.main div {
        position: relative;
        margin: 40px 0;
      }
       
      label {
        position: absolute;
        top: 0;
        font-size: 1.5em;
        margin: 6px;
        padding: 0 10px;
        -webkit-transition: top .2s ease-in-out,  font-size .2s ease-in-out;
        transition: top .2s ease-in-out,  font-size .2s ease-in-out;
      }
       
      .active {
        top: -25px;
        font-size: 1.3em;
        font-weight: 900;
        letter-spacing: 3px;
        text-transform: uppercase;
      }
       
      input[type=text] {
        width: 100%;
        padding: 20px;
        border: 2px solid white;
        font-size: 20px;
        font-weight: 800;
        background: -webkit-linear-gradient(right, #3931af, #00c6ff);
        color: white;
      }

      input[type=email] {
        width: 100%;
        padding: 20px;
        border: 2px solid white;
        font-size: 20px;
        font-weight: 800;
        background: -webkit-linear-gradient(right, #3931af, #00c6ff);
        color: white;
      }

      input[type=password] {
        width: 100%;
        padding: 20px;
        border: 2px solid white;
        font-size: 20px;
        font-weight: 800;
        background: -webkit-linear-gradient(right, #3931af, #00c6ff);
        color: white;
      }

      input[type=submit] {
        background: -webkit-linear-gradient(right, #1900e6, dodgerblue);
        color: white;
      }
       
      input[type=text]:focus {
        outline: none !important;
      }
    </style>
  </head>
 
  <body>
    <div class="main">
      <h1> Login </h1>

      <form method="post" role="form">
        <div class="form-group">
          <label for="userName"> User Name / Email </label>
          <input type="email" name="userName" id="userName" class="form-control" class="styl">
        </div>

        <div class="form-group">
          <label for="password"> Password </label>
          <input type="password" name="password" id="password" class="form-control" class="styl">
        </div>

        <div class="form-group">
          <div class="col-md-offset-8 col-xs-offset-8">
            <input type="submit" name="login" class="btn btn-warning" value="Login">
          </div>
        </div>
      </form>
      <h4> Don't Have an Account, <a href="register.php"> Register Now </a>?</h4>
    </div>
    
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <!-- <script  src="function.js"></script>  -->
    <script>
      $('input').on('focusin', function() {
        $(this).parent().find('label').addClass('active');
      });
       
      $('input').on('focusout', function() {
        if (!this.value) {
          $(this).parent().find('label').removeClass('active');
        }
      });
    </script>
  </body>
</html>