<?php 
	include_once 'function.php'; 
	$sql = $_GET['sub'];
	$res_data = $crud->selectByAjax('course_subject', 'course_cate_id', $sql);
?>

	<!-- <div class="col-md-4 col-sm-4 col-xs-12"> -->
		<select name="course_sub" class="form-control" id="showSubject" onchange="show();">
			<option value="" selected disabled="disabled"> Select Subject </option>
		<?php
			foreach ($res_data as $data) {
		?>
			<option value="<?php echo $data['id']; ?>"> <?php echo $data['course_subject']; ?> </option>
		<?php } ?>
		</select>
	<!-- </div> -->
