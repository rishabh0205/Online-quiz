<?php
  include_once 'database/connection.php';
  include_once 'function.php';

  if(isset($_POST['register'])) {
    $register = array(
      'name' => $_POST['name'],
      'email' => $_POST['email'],
      'password' => md5($_POST['password']),
      'phone' => $_POST['phone'],
      'address' => $_POST['address'],
      'type' => 'User'
    );
    if($crud->insertRecord('login_auth', $register)) {

      echo "<script> alert('Register Successfully..!'); window.location.href = 'login.php'; </script>";
    } else {

      echo $this->conn->error;
    }
  }
?>

<html lang="en" > 
  <head>
    <meta charset="UTF-8">
    <title> Register | Online Test Panel </title>
    <link href="https://fonts.googleapis.com/css?family=Alegreya+Sans+SC&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="style.css"> -->

    <style>
      * {
        letter-spacing: 3px;
        font-family: Cambria;
      }
      body {
        color: white;
        background: -webkit-linear-gradient(left, #3931af, #00c6ff);
      }

      h4 a {
        color: #fff !important;
        text-decoration: none !important;
      }
      h4 a:hover {
        color: #ddd !important;
        text-decoration: none !important;
      }
       
      h1 {
        font-size: 2.5em;
        margin: 0px;
        padding: 0px;
        text-align: center;
      }
       
      div.main {
        width: 400px;
        position: absolute;
        top: 45%;
        left: 50%;
        transform: translate(-50%, -50%);
        vertical-align: middle;
      }
       
      div.main div {
        position: relative;
        margin: 30px 0;
      }
       
      label {
        position: absolute;
        top: 0;
        font-size: 1.5em;
        margin: 6px;
        padding: 0 10px;
        -webkit-transition: top .2s ease-in-out,  font-size .2s ease-in-out;
        transition: top .2s ease-in-out,  font-size .2s ease-in-out;
      }
       
      .active {
        top: -25px;
        font-size: 1.3em;
        font-weight: 900;
        letter-spacing: 3px;
        text-transform: uppercase;
      }
       
      input[type=text] {
        width: 100%;
        padding: 20px;
        border: 2px solid white;
        font-size: 1.3em;
        background: -webkit-linear-gradient(right, #3931af, #00c6ff);
        color: white;
      }

      input[type=email] {
        width: 100%;
        padding: 20px;
        border: 2px solid white;
        font-size: 1.3em;
        background: -webkit-linear-gradient(right, #3931af, #00c6ff);
        color: white;
      }

      input[type=password] {
        width: 100%;
        padding: 20px;
        border: 2px solid white;
        font-size: 1.3em;
        background: -webkit-linear-gradient(right, #3931af, #00c6ff);
        color: white;
      }

      textarea {
        width: 100%;
        padding: 20px;
        border: 2px solid white;
        font-size: 1.3em;
        background: -webkit-linear-gradient(right, #3931af, #00c6ff) !important;
        color: white;
      }

      input[type=submit] {
        background: -webkit-linear-gradient(left, #1900e6, dodgerblue);
        color: white;
      }
       
      input[type=text]:focus {
        outline: none !important;
      }
    </style>
  </head>
 
  <body>
    <div class="main">
      <h1> Register </h1>

      <form method="post" role="form">
        <div class="form-group">
          <label for="name"> Name </label>
          <input type="text" name="name" id="name" class="form-control styl">
        </div>

        <div class="form-group">
          <label for="email"> Email </label>
          <input type="email" name="email" id="email" class="form-control styl">
        </div>

        <div class="form-group">
          <label for="password"> Password </label>
          <input type="password" name="password" id="password" class="form-control styl">
        </div>

        <div class="form-group">
          <label for="address"> Address </label>
          <textarea name="address" id="address" class="form-control styl" rows="3"></textarea>
        </div>

        <div class="form-group">
          <label for="phone"> Contact </label>
          <input type="text" name="phone" maxlength="10" id="phone" class="form-control styl">
        </div>

        <div class="form-group">
          <div class="col-md-offset-8 col-xs-offset-8">
            <input type="submit" name="register" class="btn btn-warning" value="Register">
          </div>
        </div>
      </form>
      <h4> Already Have an Account, <a href="login.php"> Login </a>!!</h4>
    </div>
    
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <!-- <script  src="function.js"></script>  -->
    <script>
      $('input').on('focusin', function() {
        $(this).parent().find('label').addClass('active');
      });
       
      $('input').on('focusout', function() {
        if (!this.value) {
          $(this).parent().find('label').removeClass('active');
        }
      });

      $('textarea').on('focusin', function() {
        $(this).parent().find('label').addClass('active');
      });
       
      $('textarea').on('focusout', function() {
        if (!this.value) {
          $(this).parent().find('label').removeClass('active');
        }
      });
    </script>
  </body>
</html>