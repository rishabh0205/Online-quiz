-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2019 at 11:07 AM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_cate`
--

CREATE TABLE `course_cate` (
  `id` int(11) NOT NULL,
  `course_category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_cate`
--

INSERT INTO `course_cate` (`id`, `course_category`) VALUES
(1, 'BCA'),
(2, 'MCA'),
(3, 'B.E.'),
(4, 'B.tech');

-- --------------------------------------------------------

--
-- Table structure for table `course_subject`
--

CREATE TABLE `course_subject` (
  `id` int(11) NOT NULL,
  `course_cate_id` varchar(255) NOT NULL,
  `course_subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_subject`
--

INSERT INTO `course_subject` (`id`, `course_cate_id`, `course_subject`) VALUES
(1, '5', 'C++'),
(3, '2', 'C++'),
(4, '2', 'JAVA'),
(6, '5', 'JAVA'),
(7, '3', 'DBMS');

-- --------------------------------------------------------

--
-- Table structure for table `login_auth`
--

CREATE TABLE `login_auth` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_auth`
--

INSERT INTO `login_auth` (`id`, `name`, `email`, `password`, `address`, `phone`, `type`, `image`) VALUES
(1, 'Rishabh Srivastava', 'rishabh@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Ramkatora, Varanasi', '7531598524', 'Admin', ''),
(2, 'Ajay Kumar Prajapati', 'ajay@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Ramkatora, Varanasi', '7531598524', 'User', ''),
(3, 'Uday Govind Pathak', 'uday@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'vns', '7531598524', 'User', '');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_set`
--

CREATE TABLE `quiz_set` (
  `id` int(11) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `set_number` varchar(255) NOT NULL,
  `question_type` varchar(255) NOT NULL,
  `timming` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_set`
--

INSERT INTO `quiz_set` (`id`, `course_id`, `subject_id`, `set_number`, `question_type`, `timming`) VALUES
(1, '2', '3', 'Set-1', 'Variables, Array, Pointer, Structure', '120 Minutes'),
(2, '2', '4', 'Set-1', 'String, Servolet', '60 Minutes');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_set_question`
--

CREATE TABLE `quiz_set_question` (
  `id` int(11) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `set_number` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `option_one` varchar(255) NOT NULL,
  `option_two` varchar(255) NOT NULL,
  `option_three` varchar(255) NOT NULL,
  `option_four` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_set_question`
--

INSERT INTO `quiz_set_question` (`id`, `course_id`, `subject_id`, `set_number`, `question`, `option_one`, `option_two`, `option_three`, `option_four`, `correct_ans`) VALUES
(1, '2', '3', 'Set-1', 'This Is Question One', 'Abc', 'Def', 'Ghi', 'Jkl', 'Abc'),
(2, '2', '3', 'Set-1', 'This Is Question Two', 'Abc', 'Def', 'Ghi', 'Jkl', 'Def'),
(3, '2', '4', 'Set-1', 'This Is Question 1', 'C++', 'Java', 'C', 'Html', 'C'),
(4, '2', '4', 'Set-1', 'This Is Question 2', 'C++', 'Java', 'Html', 'Php', 'Java'),
(5, '2', '4', 'Set-1', 'This Is Question 3', 'Php', 'C++', 'Html', 'C', 'Php');

-- --------------------------------------------------------

--
-- Table structure for table `test_record`
--

CREATE TABLE `test_record` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `set_num` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `option_check` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_record`
--

INSERT INTO `test_record` (`id`, `user_id`, `course_id`, `subject_id`, `set_num`, `question`, `option_check`, `correct_ans`, `status`) VALUES
(1, '2', '2', '4', 'Set-1', 'This Is Question 1', 'C', 'C', 'Correct'),
(2, '2', '2', '4', 'Set-1', 'This Is Question 2', 'C++', 'Java', 'Wrong'),
(3, '2', '2', '4', 'Set-1', 'This Is Question 3', 'Php', 'Php', 'Correct'),
(4, '3', '2', '4', 'Set-1', 'This Is Question 1', 'C', 'C', 'Correct'),
(5, '3', '2', '4', 'Set-1', 'This Is Question 2', 'Java', 'Java', 'Correct'),
(6, '3', '2', '4', 'Set-1', 'This Is Question 3', 'Html', 'Php', 'Wrong'),
(7, '2', '2', '4', 'Set-1', 'This Is Question 1', 'C++', 'C', 'Wrong'),
(8, '2', '2', '4', 'Set-1', 'This Is Question 2', 'Java', 'Java', 'Correct'),
(9, '2', '2', '4', 'Set-1', 'This Is Question 3', 'Html', 'Php', 'Wrong');

-- --------------------------------------------------------

--
-- Table structure for table `test_report`
--

CREATE TABLE `test_report` (
  `id` int(11) NOT NULL,
  `test_date` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `set_num` varchar(255) NOT NULL,
  `no_of_question` varchar(255) NOT NULL,
  `correct_answer` varchar(255) NOT NULL,
  `wrong_answer` varchar(255) NOT NULL,
  `accuracy` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_report`
--

INSERT INTO `test_report` (`id`, `test_date`, `user_id`, `course_id`, `subject_id`, `set_num`, `no_of_question`, `correct_answer`, `wrong_answer`, `accuracy`) VALUES
(1, '2019-09-04', '2', '2', '4', 'Set-1', '3', '3', '3', '100.00 %'),
(2, '2019-09-04', '3', '2', '4', 'Set-1', '3', '2', '1', '66.67 %'),
(3, '2019-09-04', '2', '2', '4', 'Set-1', '3', '3', '3', '100.00 %');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course_cate`
--
ALTER TABLE `course_cate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_subject`
--
ALTER TABLE `course_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_auth`
--
ALTER TABLE `login_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_set`
--
ALTER TABLE `quiz_set`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_set_question`
--
ALTER TABLE `quiz_set_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_record`
--
ALTER TABLE `test_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_report`
--
ALTER TABLE `test_report`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course_cate`
--
ALTER TABLE `course_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `course_subject`
--
ALTER TABLE `course_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `login_auth`
--
ALTER TABLE `login_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `quiz_set`
--
ALTER TABLE `quiz_set`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `quiz_set_question`
--
ALTER TABLE `quiz_set_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `test_record`
--
ALTER TABLE `test_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `test_report`
--
ALTER TABLE `test_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
