
<?php include_once 'header.php'; include_once 'function.php'; ?>
<?php
	$course = $_GET['course'];
	$set = $_GET['view'];
	$subject = $_GET['subject'];

  $show_cate = $crud->selectBy('course_cate', 'id', $course);
  $show_sub = $crud->selectById('course_subject', 'id', $subject);
?>

<style>
  .table thead th {
    text-align: center;
  }
  .table tbody td {
    text-align: center;
  }
</style>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> View Set Question </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li>
      <li><a href="#"> Manage Quiz Set </a></li>
      <li class="active"> View Set Question </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title"> <b>Course :&nbsp;&nbsp;&nbsp;<?php echo $show_cate['course_category']; ?></b>&nbsp;&nbsp; |&nbsp;&nbsp; <b>Subject :&nbsp;&nbsp;<?php echo $show_sub['course_subject']; ?></b>&nbsp;&nbsp; |&nbsp;&nbsp; <b>Set :&nbsp;&nbsp;&nbsp;<?php echo $set; ?></b> -:-</h3>
          </div>

          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th> # </th>
                  <th> Question </th>
                  <th> Option A </th>
                  <th> Option B </th>
                  <th> Option C </th>
                  <th> Option D </th>
                  <th> Correct Answer </th>
                  <th> Action </th>
                </tr>
              </thead>

              <tbody>
              <?php
                $num = 1;
                $showData = $crud->selectByData('quiz_set_question', 'course_id', $course, 'subject_id', $subject, 'set_number', $set);
                //print_r($show);
                //exit();
                foreach ($showData as $showRecord) {
              ?>
                <tr>
                  <td> <?php echo $num; ?> </td>
                  <td> <?php echo $showRecord['question']; ?> </td>
                  <td> <?php echo $showRecord['option_one']; ?> </td>
                  <td> <?php echo $showRecord['option_two']; ?> </td>
                  <td> <?php echo $showRecord['option_three']; ?> </td>
                  <td> <?php echo $showRecord['option_four']; ?> </td>
                  <td> <?php echo $showRecord['correct_ans']; ?> </td>
                  <td>
                    <a href="courseSub.php?del=<?php echo $showRecord['id']; ?>" onclick="return confirm('Are You Sure..?')"><img src="dist/img/trash.png"></a>
                  </td>
                </tr>
              <?php $num++; } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php include_once 'footer.php'; ?>